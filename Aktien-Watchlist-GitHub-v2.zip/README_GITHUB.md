# Aktien-Watchlist – GitHub-Build (v2)

GitHub entpackt `upload/aktien-app-source.zip` beim Bauen selbst und erstellt daraus eine APK.

## Schritt für Schritt
1. github.com → **New repository** → Name `aktien-watchlist` → **Private** → **Create repository**.
2. Diese ZIP auf dem Gerät entpacken (Dateien-App / Computer).
3. Im Repository: **Add file → Upload files**. Den **Inhalt** des entpackten Ordners hochladen: `.github`, `upload`, `README_GITHUB.md`, `.gitignore`.
   `.github` muss im Hauptverzeichnis liegen. Wird `.github` (versteckter Ordner) nicht angezeigt: Versteckte Dateien einblenden, oder unter **Add file → Create new file** den Namen `.github/workflows/build-android.yml` tippen und den Inhalt der Datei einfügen.
4. **Commit changes**.
5. Reiter **Actions** → Lauf „Android APK bauen“ öffnen (ca. 5–10 Min.). Startet er nicht: **Run workflow**.
6. Grüner Haken → rechts **Releases** → neuestes Release → `Aktien-Watchlist.apk` herunterladen. (Alternativ im Lauf unter **Artifacts**.)
7. APK öffnen und installieren (Android fragt nach „Installation aus unbekannten Quellen“ zulassen).

## Bei rotem Lauf
Lauf öffnen → roten Schritt aufklappen → Fehlertext kopieren und mir schicken.

## Stand
Prototyp: Watchlist mit 54 Aktien, eigenes Kürzel hinzufügen, einfaches Widget. Die Diagrammlinie ist nur ein Platzhalter, keine echten Kurse. Echte Kursdaten brauchen einen Datenanbieter (Nutzungsbedingungen und Limits prüfen).
